import SwiftUI

@main
struct EscritorioIAApp: App {
    var body: some Scene {
        WindowGroup {
            EscritorioView()
                .statusBarHidden(true)
                .persistentSystemOverlays(.hidden)
        }
    }
}
