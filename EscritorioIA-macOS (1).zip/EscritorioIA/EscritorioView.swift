import SwiftUI
import UIKit

extension View {
    func tile() -> some View {
        padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.primary.opacity(0.08), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
    func fondoDock() -> some View {
        background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).strokeBorder(.white.opacity(0.25), lineWidth: 0.5))
    }
}

// MARK: - Escritorio
struct EscritorioView: View {
    @ObservedObject private var e = Escritorio.shared

    var body: some View {
        GeometryReader { g in
            ZStack(alignment: .topLeading) {
                FondoView(n: e.fondo)
                ZStack(alignment: .topLeading) {
                    ForEach(e.ventanas) { v in
                        if !v.minimizada {
                            VentanaView(v: v, e: e)
                                .zIndex(Double(v.z))
                                .transition(.scale(scale: 0.92).combined(with: .opacity))
                        }
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)

                VStack { Spacer(); DockView(e: e).padding(.bottom, max(6, g.safeAreaInsets.bottom)) }
                    .frame(maxWidth: .infinity)
                VStack { BarraMenu(e: e, top: g.safeAreaInsets.top); Spacer() }
                if e.centro { CentroControl(e: e, top: e.arriba) }
                if e.spotlight { SpotlightView(e: e) }
                Color.black.opacity((1 - e.brillo) * 0.7).allowsHitTesting(false)
            }
            .animation(.easeOut(duration: 0.18), value: e.centro)
            .animation(.easeOut(duration: 0.18), value: e.spotlight)
            .onAppear { e.area = g.size; e.arriba = g.safeAreaInsets.top + 28 }
            .onChange(of: g.size) { e.area = g.size }
        }
        .ignoresSafeArea()
        .preferredColorScheme(e.oscuro ? .dark : .light)
        .background {
            Group {
                Button("") { e.spotlight.toggle(); e.centro = false }.keyboardShortcut(.space, modifiers: .option)
                Button("") { if let a = e.activa { e.cerrar(a.id) } }.keyboardShortcut("w", modifiers: .command)
                Button("") { if let a = e.activa { e.minimizar(a.id) } }.keyboardShortcut("m", modifiers: .command)
            }
            .opacity(0).frame(width: 0, height: 0)
        }
    }
}

struct FondoView: View {
    let n: Int
    private static let paletas: [[Color]] = [
        [Color(red: 0.05, green: 0.10, blue: 0.35), Color(red: 0.33, green: 0.20, blue: 0.70), Color(red: 0.95, green: 0.50, blue: 0.55)],
        [Color(red: 0.98, green: 0.62, blue: 0.25), Color(red: 0.90, green: 0.30, blue: 0.45), Color(red: 0.30, green: 0.15, blue: 0.55)],
        [Color(red: 0.30, green: 0.10, blue: 0.55), Color(red: 0.15, green: 0.35, blue: 0.85), Color(red: 0.95, green: 0.45, blue: 0.75)],
        [Color(white: 0.18), Color(white: 0.08), Color(white: 0.28)]
    ]
    var body: some View {
        ZStack {
            LinearGradient(colors: Self.paletas[n % Self.paletas.count], startPoint: .topLeading, endPoint: .bottomTrailing)
            RadialGradient(colors: [.white.opacity(0.25), .clear], center: .topTrailing, startRadius: 10, endRadius: 520)
        }
        .ignoresSafeArea()
    }
}

// MARK: - Barra de menús
struct BarraMenu: View {
    @ObservedObject var e: Escritorio
    let top: CGFloat

    var body: some View {
        HStack(spacing: 16) {
            Menu {
                Button("Acerca de EscritorioIA") { e.abrir(.monitor) }
                Button("Ajustes del Sistema…") { e.abrir(.ajustes) }
                Divider()
                Button("Cerrar todas las ventanas", role: .destructive) { e.ventanas.removeAll() }
            } label: { Image(systemName: "apple.logo") }

            Text(e.activa?.apli.nombre ?? "Escritorio").fontWeight(.bold).lineLimit(1)

            if e.area.width > 620 {
                Menu("Archivo") {
                    Button("Buscar con Spotlight") { e.spotlight = true }
                    Button("Cerrar ventana") { if let a = e.activa { e.cerrar(a.id) } }
                }
                Menu("Ventana") {
                    Button("Minimizar") { if let a = e.activa { e.minimizar(a.id) } }
                    Button("Zoom") { if let a = e.activa { e.zoom(a.id) } }
                    Divider()
                    ForEach(e.ventanas) { v in Button(v.apli.nombre) { e.abrir(v.apli) } }
                }
                Menu("Ayuda") {
                    Button("Abrir Terminal") { e.abrir(.terminal) }
                    Button("Preguntar al asistente") { e.abrir(.asistente) }
                }
            }
            Spacer(minLength: 8)
            Image(systemName: e.avion ? "airplane" : (e.wifi ? "wifi" : "wifi.slash"))
            Bateria()
            Button { e.spotlight.toggle(); e.centro = false } label: { Image(systemName: "magnifyingglass") }
            Button { e.centro.toggle(); e.spotlight = false } label: { Image(systemName: "switch.2") }
            TimelineView(.periodic(from: .now, by: 20)) { c in
                Text(c.date.formatted(.dateTime.weekday(.abbreviated).day().month(.abbreviated).hour().minute())).lineLimit(1)
            }
        }
        .font(.system(size: 13, weight: .medium))
        .buttonStyle(.plain)
        .tint(.primary)
        .padding(.horizontal, 12)
        .frame(height: 28)
        .padding(.top, top)
        .background(.ultraThinMaterial)
    }
}

struct Bateria: View {
    @State private var n = -1
    private func leer() { let l = UIDevice.current.batteryLevel; n = l < 0 ? -1 : Int(l * 100) }
    var body: some View {
        HStack(spacing: 3) {
            if n >= 0 { Text("\(n) %") }
            Image(systemName: n > 75 || n < 0 ? "battery.100percent" : (n > 50 ? "battery.75percent" : (n > 25 ? "battery.50percent" : "battery.25percent")))
        }
        .onAppear { UIDevice.current.isBatteryMonitoringEnabled = true; leer() }
        .onReceive(NotificationCenter.default.publisher(for: UIDevice.batteryLevelDidChangeNotification)) { _ in leer() }
    }
}

// MARK: - Dock
struct DockView: View {
    @ObservedObject var e: Escritorio
    private var iconos: some View {
        HStack(alignment: .bottom, spacing: 10) {
            ForEach(Apli.allCases) { IconoDock(a: $0, e: e) }
        }
        .padding(.horizontal, 12).padding(.top, 8).padding(.bottom, 4)
    }
    var body: some View {
        ViewThatFits(in: .horizontal) {
            iconos.fondoDock()
            ScrollView(.horizontal, showsIndicators: false) { iconos }.fondoDock()
        }
        .padding(.horizontal, 8)
    }
}

struct IconoDock: View {
    let a: Apli
    @ObservedObject var e: Escritorio
    @State private var encima = false
    private var abierta: Bool { e.ventanas.contains { $0.apli == a } }
    var body: some View {
        VStack(spacing: 3) {
            IconoApli(a: a, tam: 52)
                .scaleEffect(encima ? 1.35 : 1, anchor: .bottom)
                .animation(.spring(response: 0.25, dampingFraction: 0.6), value: encima)
                .onHover { encima = $0 }
                .onTapGesture { e.abrir(a) }
                .accessibilityLabel(a.nombre)
            Circle().fill(Color.primary.opacity(abierta ? 0.7 : 0)).frame(width: 4, height: 4)
        }
    }
}

struct IconoApli: View {
    let a: Apli
    var tam: CGFloat
    var body: some View {
        RoundedRectangle(cornerRadius: tam * 0.225, style: .continuous)
            .fill(LinearGradient(colors: a.colores, startPoint: .top, endPoint: .bottom))
            .frame(width: tam, height: tam)
            .overlay(Image(systemName: a.icono).font(.system(size: tam * 0.5, weight: .medium)).foregroundStyle(.white))
            .shadow(color: .black.opacity(0.25), radius: 3, y: 2)
    }
}

// MARK: - Ventanas
struct VentanaView: View {
    let v: Ventana
    @ObservedObject var e: Escritorio
    @State private var mov = CGSize.zero
    @State private var cre = CGSize.zero
    private var esActiva: Bool { e.activa?.id == v.id }

    var body: some View {
        VStack(spacing: 0) {
            barra
            Divider()
            AppContenido(apli: v.apli, e: e).frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .frame(width: max(260, v.rect.width + cre.width), height: max(200, v.rect.height + cre.height))
        .background(.regularMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).strokeBorder(Color.primary.opacity(esActiva ? 0.25 : 0.12), lineWidth: 0.5))
        .overlay(alignment: .bottomTrailing) {
            Color.clear.frame(width: 28, height: 28).contentShape(Rectangle())
                .gesture(DragGesture()
                    .onChanged { cre = $0.translation }
                    .onEnded { g in e.redimensionar(v.id, g.translation); cre = .zero })
        }
        .shadow(color: .black.opacity(esActiva ? 0.45 : 0.2), radius: esActiva ? 24 : 10, y: 10)
        .offset(x: v.rect.minX + mov.width, y: v.rect.minY + mov.height)
        .simultaneousGesture(TapGesture().onEnded { e.enfocar(v.id) })
    }

    private var barra: some View {
        ZStack {
            HStack(spacing: 2) {
                luz(.red, "xmark") { e.cerrar(v.id) }
                luz(.yellow, "minus") { e.minimizar(v.id) }
                luz(.green, "arrow.up.left.and.arrow.down.right") { e.zoom(v.id) }
                Spacer()
            }
            Text(v.apli.nombre).font(.system(size: 13, weight: .semibold)).opacity(esActiva ? 1 : 0.5).lineLimit(1)
        }
        .padding(.horizontal, 8)
        .frame(height: 34)
        .background(.bar)
        .contentShape(Rectangle())
        .gesture(DragGesture()
            .onChanged { mov = $0.translation }
            .onEnded { g in e.mover(v.id, g.translation); mov = .zero })
    }

    private func luz(_ c: Color, _ simbolo: String, _ accion: @escaping () -> Void) -> some View {
        Circle().fill(esActiva ? c : Color.gray.opacity(0.5)).frame(width: 13, height: 13)
            .overlay(Image(systemName: simbolo).font(.system(size: 7, weight: .black)).foregroundStyle(.black.opacity(0.6)))
            .padding(4)
            .contentShape(Circle())
            .onTapGesture(perform: accion)
    }
}

// MARK: - Centro de control
struct CentroControl: View {
    @ObservedObject var e: Escritorio
    let top: CGFloat

    var body: some View {
        ZStack(alignment: .topTrailing) {
            Color.black.opacity(0.001).onTapGesture { e.centro = false }
            VStack(spacing: 10) {
                HStack(alignment: .top, spacing: 10) {
                    VStack(alignment: .leading, spacing: 12) {
                        fila("wifi", "Wi-Fi", e.wifi ? "Conectado" : "Apagado", $e.wifi)
                        fila("dot.radiowaves.left.and.right", "Bluetooth", e.bluetooth ? "Activado" : "Apagado", $e.bluetooth)
                        fila("airplane", "Modo avión", e.avion ? "Activado" : "Apagado", $e.avion)
                    }
                    .tile()
                    VStack(spacing: 10) {
                        cuadro("moon.fill", "No molestar", $e.noMolestar)
                        cuadro("flashlight.on.fill", "Linterna", $e.linterna)
                    }
                    .frame(maxWidth: .infinity)
                }
                deslizador("Pantalla", "sun.max.fill", $e.brillo)
                deslizador("Sonido", "speaker.wave.2.fill", $e.volumen)
                HStack(spacing: 10) {
                    cuadro("circle.lefthalf.filled", "Modo oscuro", $e.oscuro)
                    accion("photo.fill", "Fondo") { e.fondo = (e.fondo + 1) % Escritorio.fondos.count }
                    accion("gearshape.fill", "Ajustes") { e.abrir(.ajustes) }
                }
            }
            .padding(12)
            .frame(width: min(340, e.area.width - 16))
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).strokeBorder(.white.opacity(0.2), lineWidth: 0.5))
            .shadow(color: .black.opacity(0.3), radius: 20, y: 8)
            .padding(.top, top + 6)
            .padding(.trailing, 8)
        }
    }

    private func circulo(_ icono: String, _ on: Bool) -> some View {
        Image(systemName: icono).font(.system(size: 14, weight: .semibold)).frame(width: 32, height: 32)
            .background(on ? Color.accentColor : Color.gray.opacity(0.35), in: Circle())
            .foregroundStyle(on ? Color.white : Color.primary)
    }
    private func fila(_ icono: String, _ titulo: String, _ sub: String, _ on: Binding<Bool>) -> some View {
        Button { on.wrappedValue.toggle() } label: {
            HStack(spacing: 8) {
                circulo(icono, on.wrappedValue)
                VStack(alignment: .leading, spacing: 0) {
                    Text(titulo).font(.system(size: 12, weight: .semibold))
                    Text(sub).font(.system(size: 11)).foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
            }
        }
        .buttonStyle(.plain)
    }
    private func cuadro(_ icono: String, _ titulo: String, _ on: Binding<Bool>) -> some View {
        Button { on.wrappedValue.toggle() } label: {
            VStack(alignment: .leading, spacing: 6) {
                circulo(icono, on.wrappedValue)
                Text(titulo).font(.system(size: 12, weight: .semibold)).lineLimit(2).multilineTextAlignment(.leading)
            }
            .tile()
        }
        .buttonStyle(.plain)
    }
    private func accion(_ icono: String, _ titulo: String, _ f: @escaping () -> Void) -> some View {
        Button(action: f) {
            VStack(alignment: .leading, spacing: 6) {
                circulo(icono, false)
                Text(titulo).font(.system(size: 12, weight: .semibold)).lineLimit(2)
            }
            .tile()
        }
        .buttonStyle(.plain)
    }
    private func deslizador(_ titulo: String, _ icono: String, _ v: Binding<Double>) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(titulo).font(.system(size: 12, weight: .semibold))
            HStack {
                Image(systemName: icono).foregroundStyle(.secondary).frame(width: 22)
                Slider(value: v, in: 0.15...1)
            }
        }
        .tile()
    }
}

// MARK: - Spotlight
struct SpotlightView: View {
    @ObservedObject var e: Escritorio
    @State private var q = ""
    @FocusState private var foco: Bool

    private var apps: [Apli] {
        let t = q.lowercased()
        return t.isEmpty ? [] : Apli.allCases.filter { $0.rawValue.contains(t) || $0.nombre.lowercased().contains(t) }
    }

    var body: some View {
        ZStack(alignment: .top) {
            Color.black.opacity(0.25).onTapGesture { e.spotlight = false }
            VStack(spacing: 0) {
                HStack(spacing: 10) {
                    Image(systemName: "magnifyingglass").font(.title2).foregroundStyle(.secondary)
                    TextField("Spotlight", text: $q)
                        .font(.system(size: 22, weight: .light))
                        .focused($foco)
                        .submitLabel(.go)
                        .onSubmit { enviar() }
                }
                .padding(14)
                if !q.isEmpty {
                    Divider()
                    VStack(spacing: 2) {
                        ForEach(apps) { a in fila(a.icono, a.nombre, "Aplicación") { e.abrir(a) } }
                        fila("sparkles", "Preguntar al asistente: \(q)", "Asistente") { e.preguntaPendiente = q; e.abrir(.asistente) }
                        fila("globe", "Buscar «\(q)» en la web", "Navegador") { e.urlPendiente = q; e.abrir(.navegador) }
                    }
                    .padding(6)
                }
            }
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .frame(maxWidth: min(560, e.area.width - 24))
            .padding(.top, e.arriba + 40)
        }
        .onAppear { foco = true }
    }

    private func enviar() {
        if let a = apps.first { e.abrir(a) }
        else if !q.isEmpty { e.preguntaPendiente = q; e.abrir(.asistente) }
    }

    private func fila(_ icono: String, _ titulo: String, _ sub: String, _ f: @escaping () -> Void) -> some View {
        Button(action: f) {
            HStack(spacing: 10) {
                Image(systemName: icono).frame(width: 26)
                Text(titulo).lineLimit(1)
                Spacer()
                Text(sub).font(.caption).foregroundStyle(.secondary)
            }
            .padding(8)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}
