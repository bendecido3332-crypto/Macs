import SwiftUI
import AVFoundation
import Speech
import FoundationModels
import AppIntents

// MARK: - Herramientas del modelo
struct AbrirAppTool: Tool {
    let name = "abrirApp"
    let description = "Abre una app del escritorio. Nombres válidos: asistente, notas, calculadora, navegador, archivos, terminal, monitor, calendario, reloj, ajustes."

    @Generable
    struct Arguments {
        @Guide(description: "Nombre de la app a abrir")
        var nombre: String
    }

    func call(arguments: Arguments) async throws -> String {
        await MainActor.run { Escritorio.shared.abrirApp(arguments.nombre) ? "Listo." : "Esa app no existe." }
    }
}

struct GuardarNotaTool: Tool {
    let name = "guardarNota"
    let description = "Guarda un texto en la app Notas."

    @Generable
    struct Arguments {
        @Guide(description: "Texto de la nota")
        var texto: String
    }

    func call(arguments: Arguments) async throws -> String {
        await MainActor.run { Escritorio.shared.notas.insert(arguments.texto, at: 0) }
        return "Nota guardada."
    }
}

// MARK: - Reconocimiento de voz
nonisolated final class Reconocedor {
    private let motor = AVAudioEngine()
    private let reconocedor = SFSpeechRecognizer(locale: Locale(identifier: "es-ES"))
    private var peticion: SFSpeechAudioBufferRecognitionRequest?
    private var tarea: SFSpeechRecognitionTask?

    func pedirPermisos() async -> Bool {
        let estado = await withCheckedContinuation { (c: CheckedContinuation<SFSpeechRecognizerAuthorizationStatus, Never>) in
            SFSpeechRecognizer.requestAuthorization { c.resume(returning: $0) }
        }
        guard estado == .authorized else { return false }
        return await AVAudioApplication.requestRecordPermission()
    }

    func iniciar(_ parcial: @escaping @MainActor (String) -> Void) throws {
        detener()
        let s = AVAudioSession.sharedInstance()
        try s.setCategory(.record, mode: .measurement, options: .duckOthers)
        try s.setActive(true, options: .notifyOthersOnDeactivation)
        let p = SFSpeechAudioBufferRecognitionRequest()
        p.shouldReportPartialResults = true
        peticion = p
        let nodo = motor.inputNode
        nodo.installTap(onBus: 0, bufferSize: 1024, format: nodo.outputFormat(forBus: 0)) { b, _ in p.append(b) }
        motor.prepare()
        try motor.start()
        tarea = reconocedor?.recognitionTask(with: p) { r, _ in
            guard let t = r?.bestTranscription.formattedString else { return }
            Task { @MainActor in parcial(t) }
        }
    }

    func detener() {
        if motor.isRunning { motor.stop(); motor.inputNode.removeTap(onBus: 0) }
        peticion?.endAudio()
        tarea?.cancel()
        peticion = nil
        tarea = nil
    }
}

// MARK: - Asistente
@MainActor
final class Asistente: ObservableObject {
    static let shared = Asistente()
    struct Msg: Identifiable { let id = UUID(); let esUsuario: Bool; let texto: String }

    @Published var mensajes: [Msg] = []
    @Published var entrada = ""
    @Published var pensando = false
    @Published var escuchando = false
    @Published var voz = false
    @Published var aviso: String?

    private var sesion: LanguageModelSession?
    private let sintetizador = AVSpeechSynthesizer()
    private let reconocedor = Reconocedor()

    var disponibilidad: String? {
        if case .available = SystemLanguageModel.default.availability { return nil }
        return "Apple Intelligence no está disponible en este dispositivo."
    }

    func preguntar(_ texto: String) async {
        let t = texto.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return }
        mensajes.append(Msg(esUsuario: true, texto: t))
        if let d = disponibilidad { mensajes.append(Msg(esUsuario: false, texto: d)); return }
        let s = sesion ?? LanguageModelSession(
            tools: [AbrirAppTool(), GuardarNotaTool()],
            instructions: "Eres un asistente breve y amable. Responde siempre en español. Puedes abrir apps del escritorio y guardar notas usando tus herramientas."
        )
        sesion = s
        pensando = true
        defer { pensando = false }
        do {
            let r = try await s.respond(to: t)
            mensajes.append(Msg(esUsuario: false, texto: r.content))
            if voz { hablar(r.content) }
        } catch {
            mensajes.append(Msg(esUsuario: false, texto: "No pude responder: \(error.localizedDescription)"))
        }
    }

    func alternarMicrofono() async {
        aviso = nil
        if escuchando {
            reconocedor.detener()
            escuchando = false
            let t = entrada
            entrada = ""
            await preguntar(t)
            return
        }
        guard await reconocedor.pedirPermisos() else {
            aviso = "Activa micrófono y reconocimiento de voz en Ajustes de iOS."
            return
        }
        do {
            try reconocedor.iniciar { [weak self] t in self?.entrada = t }
            escuchando = true
        } catch {
            aviso = "No se pudo iniciar el micrófono."
        }
    }

    private func hablar(_ t: String) {
        try? AVAudioSession.sharedInstance().setCategory(.playback)
        try? AVAudioSession.sharedInstance().setActive(true)
        let u = AVSpeechUtterance(string: t)
        u.voice = AVSpeechSynthesisVoice(language: "es-ES")
        u.volume = Float(Escritorio.shared.volumen)
        sintetizador.speak(u)
    }
}

struct AsistenteView: View {
    @ObservedObject var e: Escritorio
    @ObservedObject private var a = Asistente.shared

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 8) {
                Circle().fill(a.disponibilidad == nil ? Color.green : Color.orange).frame(width: 8, height: 8)
                Text(a.disponibilidad ?? "Apple Intelligence disponible").font(.caption).lineLimit(1)
                Spacer()
                Button { a.voz.toggle() } label: {
                    Image(systemName: "speaker.wave.2.fill").foregroundStyle(a.voz ? Color.accentColor : Color.secondary)
                }
                .accessibilityLabel("Responder en voz alta")
            }
            .padding(.horizontal, 12).padding(.vertical, 8)
            Divider()
            ScrollViewReader { p in
                ScrollView {
                    VStack(spacing: 8) {
                        if a.mensajes.isEmpty {
                            Text("Pregúntame lo que quieras o dime «abre la terminal».").foregroundStyle(.secondary).padding(.top, 30)
                        }
                        ForEach(a.mensajes) { m in
                            HStack {
                                if m.esUsuario { Spacer(minLength: 40) }
                                Text(m.texto).padding(.horizontal, 12).padding(.vertical, 8)
                                    .background(m.esUsuario ? Color.accentColor : Color.gray.opacity(0.25),
                                                in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                                    .foregroundStyle(m.esUsuario ? Color.white : Color.primary)
                                if !m.esUsuario { Spacer(minLength: 40) }
                            }
                            .id(m.id)
                        }
                        if a.pensando { ProgressView().frame(maxWidth: .infinity, alignment: .leading).padding(.leading, 8) }
                    }
                    .padding(12)
                }
                .onChange(of: a.mensajes.count) { if let l = a.mensajes.last { p.scrollTo(l.id, anchor: .bottom) } }
            }
            if let av = a.aviso { Text(av).font(.caption).foregroundStyle(.red).padding(.horizontal, 12) }
            HStack(spacing: 8) {
                TextField("Escribe o habla", text: $a.entrada)
                    .onSubmit { enviar() }
                    .padding(.horizontal, 12).padding(.vertical, 8)
                    .background(Color.primary.opacity(0.08), in: Capsule())
                Button { Task { await a.alternarMicrofono() } } label: {
                    Image(systemName: "waveform.circle.fill").font(.title)
                        .foregroundStyle(a.escuchando ? Color.red : Color.secondary)
                }
                Button { enviar() } label: { Image(systemName: "arrow.up.circle.fill").font(.title) }
                    .disabled(a.entrada.trimmingCharacters(in: .whitespaces).isEmpty)
            }
            .padding(10)
        }
        .task(id: e.preguntaPendiente) {
            if let p = e.preguntaPendiente { e.preguntaPendiente = nil; await a.preguntar(p) }
        }
    }

    private func enviar() {
        let t = a.entrada
        a.entrada = ""
        Task { await a.preguntar(t) }
    }
}

// MARK: - Siri y Atajos
struct PreguntarIntent: AppIntent {
    static let title: LocalizedStringResource = "Preguntar al asistente"

    @Parameter(title: "Pregunta")
    var pregunta: String

    func perform() async throws -> some IntentResult & ProvidesDialog {
        guard case .available = SystemLanguageModel.default.availability else {
            return .result(dialog: "Apple Intelligence no está disponible en este dispositivo.")
        }
        let s = LanguageModelSession(instructions: "Responde en español, en pocas frases.")
        let r = try await s.respond(to: pregunta)
        return .result(dialog: "\(r.content)")
    }
}

struct GuardarNotaIntent: AppIntent {
    static let title: LocalizedStringResource = "Guardar nota"

    @Parameter(title: "Texto")
    var texto: String

    func perform() async throws -> some IntentResult & ProvidesDialog {
        let t = texto
        await MainActor.run { Escritorio.shared.notas.insert(t, at: 0) }
        return .result(dialog: "Nota guardada.")
    }
}

struct AtajosEscritorio: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(intent: PreguntarIntent(),
                    phrases: ["Pregunta a \(.applicationName)", "Hablar con \(.applicationName)"],
                    shortTitle: "Preguntar al asistente", systemImageName: "sparkles")
        AppShortcut(intent: GuardarNotaIntent(),
                    phrases: ["Guardar nota en \(.applicationName)"],
                    shortTitle: "Guardar nota", systemImageName: "note.text")
    }
}
