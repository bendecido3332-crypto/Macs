import SwiftUI
import WebKit

struct AppContenido: View {
    let apli: Apli
    @ObservedObject var e: Escritorio
    var body: some View {
        switch apli {
        case .asistente: AsistenteView(e: e)
        case .notas: NotasView(e: e)
        case .calculadora: CalculadoraView()
        case .navegador: NavegadorView(e: e)
        case .archivos: ArchivosView(e: e)
        case .terminal: TerminalView(e: e)
        case .monitor: MonitorView(e: e)
        case .calendario: CalendarioView()
        case .reloj: RelojView()
        case .ajustes: AjustesView(e: e)
        }
    }
}

// MARK: - Notas
struct NotasView: View {
    @ObservedObject var e: Escritorio
    @State private var sel = 0

    private var texto: Binding<String> {
        Binding(get: { e.notas.indices.contains(sel) ? e.notas[sel] : "" },
                set: { if e.notas.indices.contains(sel) { e.notas[sel] = $0 } })
    }

    var body: some View {
        GeometryReader { g in
            HStack(spacing: 0) {
                VStack(spacing: 0) {
                    HStack {
                        Text("Notas").font(.headline)
                        Spacer()
                        Button { e.notas.insert("", at: 0); sel = 0 } label: { Image(systemName: "square.and.pencil") }
                    }
                    .padding(10)
                    List {
                        ForEach(Array(e.notas.enumerated()), id: \.offset) { i, n in
                            let l = n.components(separatedBy: "\n")
                            Button { sel = i } label: {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(l[0].isEmpty ? "Nota nueva" : l[0]).fontWeight(.semibold).lineLimit(1)
                                    Text(l.dropFirst().joined(separator: " ")).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                }
                            }
                            .buttonStyle(.plain)
                            .listRowBackground(sel == i ? Color.accentColor.opacity(0.25) : Color.clear)
                        }
                        .onDelete { e.notas.remove(atOffsets: $0); sel = 0 }
                    }
                    .listStyle(.plain)
                }
                .frame(width: min(190, g.size.width * 0.4))
                Divider()
                if e.notas.isEmpty {
                    Text("Sin notas. Pulsa el lápiz para crear una.").foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    TextEditor(text: texto).scrollContentBackground(.hidden).padding(8)
                }
            }
        }
    }
}

// MARK: - Calculadora
struct CalculadoraView: View {
    @State private var pantalla = "0"
    @State private var acumulado: Double?
    @State private var operacion: String?
    @State private var nuevo = true
    private let filas = [["AC", "±", "%", "÷"], ["7", "8", "9", "×"], ["4", "5", "6", "−"], ["1", "2", "3", "+"], ["0", ".", "="]]

    var body: some View {
        VStack(spacing: 6) {
            Text(pantalla).font(.system(size: 44, weight: .light)).minimumScaleFactor(0.4).lineLimit(1)
                .frame(maxWidth: .infinity, alignment: .trailing).padding(.horizontal, 12).padding(.top, 8)
            GeometryReader { g in
                let s: CGFloat = 6
                let w = (g.size.width - 3 * s) / 4
                let h = (g.size.height - 4 * s) / 5
                VStack(spacing: s) {
                    ForEach(filas, id: \.self) { fila in
                        HStack(spacing: s) {
                            ForEach(fila, id: \.self) { t in
                                Button { pulsar(t) } label: {
                                    Text(t).font(.system(size: 22, weight: .medium))
                                        .frame(width: t == "0" ? 2 * w + s : w, height: h)
                                        .background(color(t), in: RoundedRectangle(cornerRadius: min(w, h) / 2.4, style: .continuous))
                                        .foregroundStyle(esOp(t) ? Color.white : Color.primary)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
            }
            .padding(8)
        }
    }

    private func esOp(_ t: String) -> Bool { "÷×−+=".contains(t) }
    private func color(_ t: String) -> Color {
        esOp(t) ? .orange : (["AC", "±", "%"].contains(t) ? Color.gray.opacity(0.5) : Color.gray.opacity(0.25))
    }
    private func fmt(_ r: Double) -> String {
        guard r.isFinite else { return "Error" }
        return r == r.rounded() && abs(r) < 1e15 ? String(Int(r)) : String(r)
    }
    private func calcular() {
        let v = Double(pantalla) ?? 0
        if let a = acumulado, let o = operacion, !nuevo {
            let r: Double
            switch o {
            case "+": r = a + v
            case "−": r = a - v
            case "×": r = a * v
            default: r = a / v
            }
            pantalla = fmt(r)
            acumulado = r.isFinite ? r : nil
        } else if !nuevo || acumulado == nil {
            acumulado = v
        }
    }
    private func pulsar(_ t: String) {
        switch t {
        case "AC": pantalla = "0"; acumulado = nil; operacion = nil; nuevo = true
        case "±": pantalla = fmt(-(Double(pantalla) ?? 0))
        case "%": pantalla = fmt((Double(pantalla) ?? 0) / 100)
        case "÷", "×", "−", "+": calcular(); operacion = t; nuevo = true
        case "=": calcular(); operacion = nil; nuevo = true
        case ".":
            if nuevo { pantalla = "0."; nuevo = false } else if !pantalla.contains(".") { pantalla += "." }
        default:
            if nuevo || pantalla == "0" { pantalla = t; nuevo = false } else { pantalla += t }
        }
    }
}

// MARK: - Navegador
@MainActor
final class Navegador: NSObject, ObservableObject, WKNavigationDelegate {
    let web = WKWebView(frame: .zero)
    @Published var direccion = ""
    @Published var atras = false
    @Published var adelante = false

    override init() {
        super.init()
        web.navigationDelegate = self
        ir("https://duckduckgo.com")
    }

    func ir(_ texto: String) {
        let s = texto.trimmingCharacters(in: .whitespaces)
        guard !s.isEmpty else { return }
        var u: URL?
        if s.hasPrefix("http://") || s.hasPrefix("https://") { u = URL(string: s) }
        else if s.contains(".") && !s.contains(" ") { u = URL(string: "https://" + s) }
        if u == nil { u = URL(string: "https://duckduckgo.com/?q=" + (s.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? s)) }
        if let u { web.load(URLRequest(url: u)) }
    }

    func webView(_ w: WKWebView, didFinish navigation: WKNavigation!) {
        direccion = w.url?.absoluteString ?? ""
        atras = w.canGoBack
        adelante = w.canGoForward
    }
}

struct WebView: UIViewRepresentable {
    let web: WKWebView
    func makeUIView(context: Context) -> WKWebView { web }
    func updateUIView(_ v: WKWebView, context: Context) {}
}

struct NavegadorView: View {
    @ObservedObject var e: Escritorio
    @StateObject private var nav = Navegador()

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                Button { nav.web.goBack() } label: { Image(systemName: "chevron.left") }.disabled(!nav.atras)
                Button { nav.web.goForward() } label: { Image(systemName: "chevron.right") }.disabled(!nav.adelante)
                Button { nav.web.reload() } label: { Image(systemName: "arrow.clockwise") }
                TextField("Buscar o escribir dirección", text: $nav.direccion)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.webSearch)
                    .onSubmit { nav.ir(nav.direccion) }
                    .padding(.horizontal, 12).padding(.vertical, 6)
                    .background(Color.primary.opacity(0.08), in: Capsule())
            }
            .padding(8)
            WebView(web: nav.web)
        }
        .task(id: e.urlPendiente) {
            if let u = e.urlPendiente { e.urlPendiente = nil; nav.ir(u) }
        }
    }
}

// MARK: - Finder
struct ArchivosView: View {
    @ObservedObject var e: Escritorio
    @State private var sel: String?

    var body: some View {
        let a = e.almacenamiento()
        HStack(spacing: 0) {
            VStack(alignment: .leading, spacing: 6) {
                Text("Favoritos").font(.caption).foregroundStyle(.secondary)
                Label("Documentos", systemImage: "folder.fill").font(.callout).padding(6)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.accentColor.opacity(0.25), in: RoundedRectangle(cornerRadius: 6))
                Spacer()
            }
            .padding(10).frame(width: 140)
            Divider()
            VStack(spacing: 0) {
                HStack(spacing: 14) {
                    Button { e.tocar("Sin título \(e.listar().count + 1).txt") } label: { Label("Nuevo", systemImage: "doc.badge.plus") }
                    Button(role: .destructive) { if let s = sel { _ = e.borrar(s); sel = nil } } label: { Label("Borrar", systemImage: "trash") }
                        .disabled(sel == nil)
                    Spacer()
                }
                .font(.callout).padding(8)
                ScrollView {
                    VStack(spacing: 2) {
                        ForEach(e.listar(), id: \.self) { n in
                            Button { sel = n } label: {
                                Label(n, systemImage: "doc.text").frame(maxWidth: .infinity, alignment: .leading).padding(6)
                                    .background(sel == n ? Color.accentColor.opacity(0.25) : Color.clear, in: RoundedRectangle(cornerRadius: 6))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, 8)
                }
                Divider()
                Text(sel.flatMap { e.leer($0) } ?? "Selecciona un archivo")
                    .font(.system(.caption, design: .monospaced)).foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, minHeight: 44, alignment: .topLeading).padding(8)
                Text("Almacenamiento libre: \(ByteCountFormatter.string(fromByteCount: a.libre, countStyle: .file))")
                    .font(.caption2).foregroundStyle(.secondary).padding(.bottom, 6)
            }
        }
    }
}

// MARK: - Terminal
struct TerminalView: View {
    @ObservedObject var e: Escritorio
    @State private var salida = ["EscritorioIA Terminal. Escribe 'ayuda'."]
    @State private var entrada = ""
    @FocusState private var foco: Bool

    var body: some View {
        VStack(spacing: 0) {
            ScrollViewReader { p in
                ScrollView {
                    VStack(alignment: .leading, spacing: 2) {
                        ForEach(Array(salida.enumerated()), id: \.offset) { i, l in Text(l).id(i) }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading).padding(8)
                }
                .onChange(of: salida.count) { p.scrollTo(salida.count - 1, anchor: .bottom) }
            }
            HStack {
                Text("$").foregroundStyle(.green)
                TextField("", text: $entrada)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .focused($foco)
                    .onSubmit { enviar() }
            }
            .padding(8).background(Color.white.opacity(0.08))
        }
        .font(.system(size: 13, design: .monospaced))
        .foregroundStyle(.white)
        .background(Color.black.opacity(0.88))
    }

    private func enviar() {
        let l = entrada.trimmingCharacters(in: .whitespaces)
        entrada = ""; foco = true
        guard !l.isEmpty else { return }
        salida.append("$ " + l)
        if let r = e.ejecutar(l) { if !r.isEmpty { salida.append(r) } } else { salida = [] }
    }
}

// MARK: - Monitor de Actividad
struct MonitorView: View {
    @ObservedObject var e: Escritorio
    var body: some View {
        TimelineView(.periodic(from: .now, by: 3)) { _ in
            let a = e.almacenamiento()
            let fmt = { (b: Int64) in ByteCountFormatter.string(fromByteCount: b, countStyle: .file) }
            Form {
                Section("Almacenamiento") {
                    Gauge(value: Double(max(0, a.total - a.libre)), in: 0...Double(max(a.total, 1))) { Text("Usado") }
                    LabeledContent("Almacenamiento libre", value: fmt(a.libre))
                    LabeledContent("Capacidad", value: fmt(a.total))
                }
                Section("Sistema") {
                    LabeledContent("Sistema", value: "iOS \(UIDevice.current.systemVersion)")
                    LabeledContent("Memoria", value: fmt(Int64(ProcessInfo.processInfo.physicalMemory)))
                    LabeledContent("Procesadores", value: "\(ProcessInfo.processInfo.activeProcessorCount)")
                    LabeledContent("Ventanas abiertas", value: "\(e.ventanas.count)")
                }
            }
            .scrollContentBackground(.hidden)
        }
    }
}

// MARK: - Calendario
struct CalendarioView: View {
    @State private var mes = Date()
    private let cal = Calendar.current

    private var celdas: [Int?] {
        let ini = cal.date(from: cal.dateComponents([.year, .month], from: mes)) ?? mes
        let n = cal.range(of: .day, in: .month, for: ini)?.count ?? 30
        let off = (cal.component(.weekday, from: ini) - cal.firstWeekday + 7) % 7
        let vacias: [Int?] = Array(repeating: nil, count: off)
        let dias: [Int?] = (1...n).map { Optional($0) }
        return vacias + dias
    }
    private var cabecera: [String] {
        let s = cal.veryShortWeekdaySymbols
        let f = cal.firstWeekday - 1
        return Array(s[f...]) + Array(s[..<f])
    }
    private func esHoy(_ d: Int) -> Bool {
        cal.isDate(Date(), equalTo: mes, toGranularity: .month) && cal.component(.day, from: Date()) == d
    }

    var body: some View {
        VStack(spacing: 10) {
            HStack(spacing: 14) {
                Text(mes.formatted(.dateTime.month(.wide).year())).font(.title2.bold())
                Spacer()
                Button { mes = cal.date(byAdding: .month, value: -1, to: mes) ?? mes } label: { Image(systemName: "chevron.left") }
                Button("Hoy") { mes = Date() }
                Button { mes = cal.date(byAdding: .month, value: 1, to: mes) ?? mes } label: { Image(systemName: "chevron.right") }
            }
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 7), spacing: 6) {
                ForEach(Array(cabecera.enumerated()), id: \.offset) { _, d in
                    Text(d).font(.caption).foregroundStyle(.secondary)
                }
                ForEach(Array(celdas.enumerated()), id: \.offset) { _, d in
                    if let d {
                        Text("\(d)").frame(width: 30, height: 30)
                            .background(esHoy(d) ? Color.red : Color.clear, in: Circle())
                            .foregroundStyle(esHoy(d) ? Color.white : Color.primary)
                            .frame(maxWidth: .infinity)
                    } else {
                        Color.clear.frame(height: 30)
                    }
                }
            }
            Spacer()
        }
        .padding(14)
    }
}

// MARK: - Reloj
struct RelojView: View {
    var body: some View {
        TimelineView(.periodic(from: .now, by: 1)) { c in
            let k = Calendar.current
            let min = Double(k.component(.minute, from: c.date))
            let seg = Double(k.component(.second, from: c.date))
            let hora = Double(k.component(.hour, from: c.date) % 12) + min / 60
            VStack(spacing: 14) {
                ZStack {
                    Circle().strokeBorder(Color.primary.opacity(0.3), lineWidth: 2)
                    ForEach(0..<12, id: \.self) { i in
                        Capsule().frame(width: 2, height: 8).offset(y: -72).rotationEffect(.degrees(Double(i) * 30))
                    }
                    mano(45, 4, hora * 30)
                    mano(65, 3, (min + seg / 60) * 6)
                    mano(70, 1.5, seg * 6, .orange)
                    Circle().frame(width: 8, height: 8)
                }
                .frame(width: 160, height: 160)
                Text(c.date.formatted(date: .omitted, time: .standard))
                    .font(.system(size: 32, weight: .light, design: .rounded)).monospacedDigit()
                Text(c.date.formatted(date: .complete, time: .omitted)).foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }

    private func mano(_ largo: CGFloat, _ ancho: CGFloat, _ grados: Double, _ c: Color = .primary) -> some View {
        Capsule().fill(c).frame(width: ancho, height: largo).offset(y: -largo / 2).rotationEffect(.degrees(grados))
    }
}

// MARK: - Ajustes del Sistema
struct AjustesView: View {
    @ObservedObject var e: Escritorio
    var body: some View {
        Form {
            Section("Apariencia") {
                Toggle("Modo oscuro", isOn: $e.oscuro)
                Picker("Fondo de pantalla", selection: $e.fondo) {
                    ForEach(0..<Escritorio.fondos.count, id: \.self) { Text(Escritorio.fondos[$0]).tag($0) }
                }
            }
            Section("Pantalla y sonido") {
                LabeledContent("Brillo") { Slider(value: $e.brillo, in: 0.15...1) }
                LabeledContent("Volumen del asistente") { Slider(value: $e.volumen, in: 0...1) }
            }
            Section("Asistente") {
                LabeledContent("Apple Intelligence", value: Asistente.shared.disponibilidad == nil ? "Disponible" : "No disponible")
            }
        }
        .scrollContentBackground(.hidden)
    }
}
