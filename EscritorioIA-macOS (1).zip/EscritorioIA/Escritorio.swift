import SwiftUI
import AVFoundation
import UIKit

enum Apli: String, CaseIterable, Identifiable {
    case asistente, notas, calculadora, navegador, archivos, terminal, monitor, calendario, reloj, ajustes
    var id: String { rawValue }

    var nombre: String {
        switch self {
        case .archivos: "Finder"
        case .monitor: "Monitor de Actividad"
        case .ajustes: "Ajustes del Sistema"
        default: rawValue.capitalized
        }
    }
    var icono: String {
        switch self {
        case .asistente: "sparkles"
        case .notas: "note.text"
        case .calculadora: "plusminus.circle.fill"
        case .navegador: "safari.fill"
        case .archivos: "folder.fill"
        case .terminal: "terminal.fill"
        case .monitor: "waveform.path.ecg"
        case .calendario: "calendar"
        case .reloj: "clock.fill"
        case .ajustes: "gearshape.fill"
        }
    }
    var colores: [Color] {
        switch self {
        case .asistente: [.purple, .indigo]
        case .notas: [.yellow, .orange]
        case .calculadora: [Color(white: 0.45), Color(white: 0.2)]
        case .navegador: [.cyan, .blue]
        case .archivos: [.blue, .teal]
        case .terminal: [Color(white: 0.28), .black]
        case .monitor: [.green, .teal]
        case .calendario: [.red, .pink]
        case .reloj: [Color(white: 0.25), .black]
        case .ajustes: [Color(white: 0.6), Color(white: 0.35)]
        }
    }
}

struct Ventana: Identifiable {
    let id = UUID()
    var apli: Apli
    var rect: CGRect
    var previo: CGRect?
    var minimizada = false
    var z = 0
}

@MainActor
final class Escritorio: ObservableObject {
    static let shared = Escritorio()
    static let fondos = ["Sequoia", "Sonoma", "Monterey", "Grafito"]

    private let ud = UserDefaults.standard
    private let raiz = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    private var zTop = 0

    @Published var ventanas: [Ventana] = []
    @Published var area = CGSize(width: 800, height: 600)
    @Published var arriba: CGFloat = 28
    @Published var oscuro: Bool { didSet { ud.set(oscuro, forKey: "oscuro") } }
    @Published var fondo: Int { didSet { ud.set(fondo, forKey: "fondo") } }
    @Published var notas: [String] { didSet { ud.set(notas, forKey: "notas") } }
    @Published var brillo = 1.0
    @Published var volumen = 0.7
    @Published var wifi = true
    @Published var bluetooth = true
    @Published var avion = false { didSet { if avion { wifi = false; bluetooth = false } } }
    @Published var noMolestar = false
    @Published var linterna = false { didSet { Self.torch(linterna) } }
    @Published var centro = false
    @Published var spotlight = false
    @Published var preguntaPendiente: String?
    @Published var urlPendiente: String?

    init() {
        oscuro = ud.object(forKey: "oscuro") as? Bool ?? true
        fondo = ud.integer(forKey: "fondo")
        notas = ud.stringArray(forKey: "notas") ?? []
        if listar().isEmpty { tocar("Hola.txt", contenido: "Hola desde EscritorioIA") }
    }

    // MARK: Ventanas
    var activa: Ventana? { ventanas.filter { !$0.minimizada }.max { $0.z < $1.z } }
    private func idx(_ id: UUID) -> Int? { ventanas.firstIndex { $0.id == id } }
    private func siguienteZ() -> Int { zTop += 1; return zTop }

    func abrir(_ a: Apli) {
        centro = false; spotlight = false
        if let k = ventanas.firstIndex(where: { $0.apli == a }) {
            ventanas[k].minimizada = false
            ventanas[k].z = siguienteZ()
            return
        }
        let n = CGFloat(ventanas.count % 6) * 28
        let chica = a == .calculadora
        let w = max(280, min(area.width - 24, chica ? 300 : 640))
        let h = max(260, min(area.height - arriba - 110, 460))
        let x = max(8, (area.width - w) / 2 - 50 + n)
        withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
            ventanas.append(Ventana(apli: a, rect: CGRect(x: x, y: arriba + 14 + n, width: w, height: h), z: siguienteZ()))
        }
    }
    func abrirApp(_ nombre: String) -> Bool {
        guard let a = Apli(rawValue: nombre.lowercased().trimmingCharacters(in: .whitespaces)) else { return false }
        abrir(a)
        return true
    }
    func enfocar(_ id: UUID) {
        if let k = idx(id), activa?.id != id { ventanas[k].z = siguienteZ() }
    }
    func cerrar(_ id: UUID) {
        withAnimation(.easeOut(duration: 0.15)) { ventanas.removeAll { $0.id == id } }
    }
    func minimizar(_ id: UUID) {
        if let k = idx(id) { withAnimation(.easeIn(duration: 0.2)) { ventanas[k].minimizada = true } }
    }
    func zoom(_ id: UUID) {
        guard let k = idx(id) else { return }
        withAnimation(.easeInOut(duration: 0.2)) {
            if let p = ventanas[k].previo {
                ventanas[k].rect = p
                ventanas[k].previo = nil
            } else {
                ventanas[k].previo = ventanas[k].rect
                ventanas[k].rect = CGRect(x: 0, y: arriba, width: area.width, height: max(240, area.height - arriba - 96))
            }
        }
    }
    func mover(_ id: UUID, _ t: CGSize) {
        guard let k = idx(id) else { return }
        var r = ventanas[k].rect
        r.origin.x += t.width
        r.origin.y = max(arriba, r.origin.y + t.height)
        ventanas[k].rect = r
        ventanas[k].previo = nil
    }
    func redimensionar(_ id: UUID, _ t: CGSize) {
        guard let k = idx(id) else { return }
        let s = ventanas[k].rect.size
        ventanas[k].rect.size = CGSize(width: max(260, s.width + t.width), height: max(200, s.height + t.height))
        ventanas[k].previo = nil
    }

    // MARK: Archivos reales (carpeta Documentos de la app)
    private func url(_ n: String) -> URL { raiz.appendingPathComponent((n as NSString).lastPathComponent) }
    func listar() -> [String] {
        ((try? FileManager.default.contentsOfDirectory(atPath: raiz.path)) ?? []).filter { !$0.hasPrefix(".") }.sorted()
    }
    func leer(_ n: String) -> String? { try? String(contentsOf: url(n), encoding: .utf8) }
    func tocar(_ n: String, contenido: String = "") {
        guard !n.isEmpty else { return }
        if !FileManager.default.fileExists(atPath: url(n).path) {
            try? contenido.write(to: url(n), atomically: true, encoding: .utf8)
        }
        objectWillChange.send()
    }
    func borrar(_ n: String) -> Bool {
        defer { objectWillChange.send() }
        return (try? FileManager.default.removeItem(at: url(n))) != nil
    }
    func almacenamiento() -> (libre: Int64, total: Int64) {
        let v = try? raiz.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey, .volumeTotalCapacityKey])
        return (v?.volumeAvailableCapacityForImportantUsage ?? 0, Int64(v?.volumeTotalCapacity ?? 0))
    }

    // MARK: Terminal (devuelve nil para "clear")
    func ejecutar(_ linea: String) -> String? {
        let p = linea.split(separator: " ", maxSplits: 1).map(String.init)
        guard let c = p.first else { return "" }
        let arg = p.count > 1 ? p[1] : ""
        switch c {
        case "ayuda": return "ls, cat <f>, touch <f>, rm <f>, echo <t>, date, clear"
        case "ls": return listar().joined(separator: "  ")
        case "cat": return leer(arg) ?? "no existe: \(arg)"
        case "touch": tocar(arg); return ""
        case "rm": return borrar(arg) ? "" : "no se pudo borrar"
        case "echo": return arg
        case "date": return Date().formatted(date: .complete, time: .standard)
        case "clear": return nil
        default: return "comando no encontrado: \(c)"
        }
    }

    nonisolated static func torch(_ on: Bool) {
        guard let d = AVCaptureDevice.default(for: .video), d.hasTorch else { return }
        try? d.lockForConfiguration()
        d.torchMode = on ? .on : .off
        d.unlockForConfiguration()
    }
}
