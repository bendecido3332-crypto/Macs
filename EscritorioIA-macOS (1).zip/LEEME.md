# EscritorioIA estilo macOS

Reescritura en SwiftUI de EscritorioIA con aspecto de Mac: barra de menús, Dock,
ventanas con semáforos (cerrar, minimizar, zoom; se arrastran y se redimensionan
desde la esquina inferior derecha), Centro de control y Spotlight.
Mantiene tus 10 apps: Asistente, Notas, Calculadora, Navegador, Finder (Archivos),
Terminal, Monitor de Actividad, Calendario, Reloj y Ajustes del Sistema.

## Cómo montarlo en Xcode
1. Xcode > File > New > Project > iOS > App. Nombre: EscritorioIA, Interface: SwiftUI, Language: Swift.
2. Borra `ContentView.swift` y el archivo `EscritorioIAApp.swift` que crea Xcode.
3. Arrastra los 5 archivos .swift de la carpeta EscritorioIA al proyecto (marca "Copy items if needed").
4. En el target > General, pon Minimum Deployments en iOS 26.0.
5. En el target > Info, añade estas dos claves:
   - Privacy - Microphone Usage Description: Para hablar con el asistente.
   - Privacy - Speech Recognition Usage Description: Para convertir tu voz en texto.
6. En Build Settings busca "Default Actor Isolation" y ponlo en nonisolated (evita errores de concurrencia).
7. Ejecuta en un iPad (o iPhone) con Apple Intelligence activado para que el asistente responda.

## Atajos de teclado (teclado físico en iPad)
- Opción + Espacio: Spotlight
- Comando + W: cerrar la ventana activa
- Comando + M: minimizar la ventana activa

## Qué es real y qué es visual en el Centro de control
- Real: Modo oscuro, Linterna, Fondo de pantalla.
- Solo visual (iOS no permite que una app los controle): Wi-Fi, Bluetooth, Modo avión, No molestar.
- Brillo: atenúa la pantalla dentro de la app. Sonido: controla el volumen de la voz del asistente.
